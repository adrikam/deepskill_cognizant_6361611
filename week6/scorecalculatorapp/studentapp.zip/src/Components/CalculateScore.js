import React from 'react';

function CalculateScore() {
  return (
    <div>
      <h2>Student Details:</h2>
      <p><b>Name:</b> Steeve</p>
      <p><b>School:</b> DNV Public School</p>
      <p><b>Total:</b> 284 Marks</p>
      <p><b>Score:</b> 94.67%</p>
    </div>
  );
}

export default CalculateScore;
